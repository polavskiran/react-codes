import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link, useHistory,useLocation } from 'react-router-dom';
import "../components/courses.css";
import Certificate from "../components/Certificate";
import { useParams } from "react-router";
import axios from "axios";
//import NavbarUser from '../NavbarUser/NavbarUser'

export default function ReactJSDetails(){

    const [showCourseDetails,setShowCourseDetails] = useState(false);
    let history = useHistory();
    const location = useLocation();
    const { id,emp_id } = useParams();
    const [result3, setResult3] = useState({result: ""});
    const [result2, setResult2] = useState({result: ""});
    const [enrollId, setEnrollId] = useState('');

    function showCertificate() {
        alert("Course Completed");
        completeCourse();
        return history.push({pathname: '/certificate', state: `${result2.empid}`});
    }

    function showCourseContent(){
        fetchCourseDetail();
        setShowCourseDetails(true);
    }

    const fetchCourseDetail = async () => {

        const resp_course = await axios.get(`http://10.208.66.112:8080/course/5`);
        console.log(resp_course.data);
        setResult3(resp_course.data);
    }

    useEffect(() => {
        userDetails()
    },[]);
    
    //console.log(location.state); // result: 'some_value'    

    const userDetails = async () => {
        const resp2 = await axios.get(`http://10.208.66.112:8080/user/${location.state}`);
        setResult2(resp2.data);
        //console.log(resp2.data);
    }

    const enrollCourse = async () => {
        //console.log(id+" : "+emp_id);
        
        //console.log("testing authot" + result3.course_author);
        const courseDetails = {course_id: "2", emp_id: result2.empid, course_name: result3.course_name, 
        course_author: result3.course_author, course_description: result3.course_description, course_enrolled_status: "Pending", course_duration: result3.course_duration};
        const resp = await axios.post('http://10.208.66.112:8080/enrolling', courseDetails);
        setEnrollId(resp.data.enroll_id);
        //console.log(resp);
    }

    const completeCourse = async () => {

        const courseDetails = {enroll_id:enrollId, course_id: "1", emp_id: result2.empid, course_name: result3.course_name, course_author: result3.course_author, course_description: result3.course_description, course_enrolled_status: "Completed", course_duration: result3.course_duration};

        const resp = await axios.post('http://10.208.66.112:8080/enrolling', courseDetails);

        console.log("Final: "+resp);
    }

    function saveCourse(e) {
        console.log(id+" : "+emp_id);
        e.preventDefault();

        fetchCourseDetail();
        enrollCourse();
    }

    return( 
        <>
            {/* <NavbarUser/> */}
            <form name="pythonForm" onLoad={fetchCourseDetail} onSubmit={saveCourse}>
                <div className="split left">
                    <div className="centered">
                        <img src={process.env.PUBLIC_URL +`/favicon.ico`} style={{width: "150px", height: "150px"}} />
                        {/* <h3>Python Course</h3> */}
                        <br/ ><br/ >
                        <h2><strong>Course Content</strong></h2>
                        <span className="curriculum--content-length">
                                23 sections<strong>.</strong> 130 Lectures<strong>.</strong> 25h 30m length
                            </span>
                        <button className="coursebtn" onClick={showCourseContent}>Enroll</button>
                    </div>
                </div>
            
                <div className="split right">
                    <div className="course-desc">
                        <strong>React is a JavaScript library for building user interfaces.</strong>
                        <br /><br />
                        <strong style={{color: "crimson"}}>What you'll learn!</strong>
                        <ul className="c">
                            <li>Build powerful, fast, user-friendly and reactive web apps</li>
                            <li>Provide amazing user experiences by leveraging the power of JavaScript with ease</li>
                            <li>Learn all about React Hooks and React Components</li>
                        </ul>
                        {
                            showCourseDetails && (
                            
                                <div className="udlite-text-sm">
                                <button className="coursebtn" onClick={showCertificate} id='btnComplete'>Complete</button>
                                </div>
                            )
                        }
                    </div>
                </div>
            </form>
        </>
        
    );
}