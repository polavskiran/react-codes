import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Switch, Route, Link, useHistory,useLocation } from 'react-router-dom';
import "../components/courses.css";
import Certificate from "../components/Certificate";
import { useParams } from "react-router";
import axios from "axios";
//import NavbarUser from '../NavbarUser/NavbarUser';

export default function PythonDetails(){

    const [showCourseDetails,setShowCourseDetails] = useState(false);
    let history = useHistory();
    const { id,emp_id } = useParams();
    const [result3, setResult3] = useState({result: ""});
    const [enrollId, setEnrollId] = useState('');
    const location = useLocation();   
    const [result2, setResult2] = useState({result: ""});

    function showCertificate() {
        alert("Course Completed");
        completeCourse();
        return history.push({pathname: '/certificate', state: `${result2.empid}`});
    }

    function showCourseContent(){
        fetchCourseDetail();
        setShowCourseDetails(true);
    }

    const fetchCourseDetail = async () => {

        const resp_course = await axios.get(`http://10.208.66.112:8080/course/2`);

        console.log(resp_course.data);
        setResult3(resp_course.data);
    }

    useEffect(() => {
        userDetails()
    },[]);       

    const userDetails = async () => {
    const resp2 = await axios.get(`http://10.208.66.112:8080/user/${location.state}`);
    setResult2(resp2.data);
    console.log(resp2.data);
    console.log("this is phy course")
    console.log(resp2.data.name);
    console.log(result2.name);

        }

    const enrollCourse = async () => {        
        const courseDetails = {course_id: "2", emp_id: result2.empid, course_name: result3.course_name, 
        course_author: result3.course_author, course_description: result3.course_description, course_enrolled_status: "Pending", course_duration: result3.course_duration};
        const resp = await axios.post('http://10.208.66.112:8080/enrolling', courseDetails);
        setEnrollId(resp.data.enroll_id);

        console.log(resp);
    }

    const completeCourse = async () => {

        const courseDetails = {enroll_id:enrollId,course_id: "1", emp_id: result2.empid, course_name: result3.course_name, course_author: result3.course_author, course_description: result3.course_description, course_enrolled_status: "Completed", course_duration: result3.course_duration};

        const resp = await axios.post('http://10.208.66.112:8080/enrolling', courseDetails);
    }

    function saveCourse(e) {
        console.log(id+" : "+emp_id);
        e.preventDefault();

        fetchCourseDetail();
        enrollCourse();
    }

    return(   
            
        <>
            {/* <NavbarUser/> */}
            <form name="pythonForm" onLoad={fetchCourseDetail} onSubmit={saveCourse}>
                <div className="split left">
                    <div className="centered">
                        <img src={process.env.PUBLIC_URL +`/PythonCourse.jpg`} style={{width: "250px", height: "150px"}} />
                        <br/ ><br/ >
                        <h2><strong>Course Content</strong></h2>
                        {/* <h3>Python Course</h3> */}
                        <span className="curriculum--content-length">
                            23 sections <strong>.</strong> 130 Lectures <strong>.</strong> 25h 30m length
                        </span>
                        <button className="coursebtn" onClick={showCourseContent}>Enroll</button>
                    </div>
                </div>
            
                <div className="split right">
                    <div className="course-desc">
                        <strong></strong>
                        <br /><br />
                        <strong style={{color: "crimson"}}>What you'll learn!</strong>
                        <ul className="c">                            
                            <br />
                            <li>Learn to use Python professionally, learning both Python 2 and Python 3!</li>
                            <li>Get an understanding of how to create GUIs in the Jupyter Notebook system!</li>
                            <li>Learn to use Object Oriented Programming with classes!</li>
                            <li>Build a complete understanding of Python from the ground up!</li>
                        </ul>
                        {
                            showCourseDetails && (                            
                            
                            <div className="udlite-text-sm">
                                <button className="coursebtn" onClick={showCertificate} id='btnComplete'>Complete</button>
                            </div>
                            )
                        }
                    </div>
                </div>
            </form>
        </>
    );
}