import React,{useEffect,useState} from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import axios from 'axios';
import NavbarUser from './Components/NavbarUser/NavbarUser'

//import NavbarUser from './Components/NavbarUser/NavbarUser';

import "./Components/Pages/Table.css"

 
function EnrolledCourse() {

 

    const [courses, setCourses] = useState([]);
    const history = useHistory();
      const location = useLocation();
      console.log("enroll" + location.state);
 

    useEffect(() => {

        //userDetails();

        fetchCourseDetail();

    },[]);

 

    const fetchCourseDetail = async () => {

        const resp = await axios.get(`http://10.208.66.112:8080/enrolledcourses/${location.state}`);

        console.log("dta --- "+resp.data[0].course_id);
        
        setCourses(resp.data);

    }   

    return(

        <div>
            <NavbarUser/>

           <center> <h2>Enrolled Course Details...</h2></center>

            <center><table className="enrolltable" border='1'>

                <thead>

                    <tr>

                        <th>Course Name</th>

                        <th>Course Description</th>

                        <th>Course Duration</th>

                        <th>Course Status</th>

                        <th>View certificate</th>

                    </tr>

                </thead>

                <tbody>
                {courses.map((e)=>{       return ( 
                    <tr>

                    <td>{e.course_id}</td>

                    <td>{e.course_description}</td>

                     <td>{e.course_duration}</td>

                    <td>{e.course_enrolled_status}</td>

                     <td><a href="">view certificate</a></td> 
                 
                 </tr>      
                     );})}

                </tbody>

            </table></center>

        </div>

    )  

}


export default EnrolledCourse;