import React, {useState} from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';
import Home from './Components/Body/Home';
import logo from './logo.svg';
import './App.css';
import Footer from './Components/Layout/Footer';
import Header from './Components/Layout/Header';
import LoginForm from './Components/LoginForm';
import HomeUser from './Components/Body/HomeUser';
import RegisterForm from './Components/RegisterForm';
import AdminHome from './Components/Pages/AdminHome';
import About from './Components/Pages/about'
import CourseList from './Components/Pages/CourseList'
import Users from './Components/Pages/Users'
import Java from './Components/Pages/JavaCourseDetails';
import Python from './Components/Pages/PythonCourseDetails';
import Groovy from './Components/Pages/GroovyCourseDetails';
import Selenium from './Components/Pages/SeleniumCourseDetails'
import EnrolledCourse from './EnrolledCourse';
import Certificate from './Components/Certificate';

function App() {

  
  // const Logout =() =>{
  //   setUser({name: "" , email: ""});
  // }



  return (
    <div className="page-container">
    {/* <Header/> */}
    <div className="content-wrap" >
      <Router>
          <Switch>
                <Route path="/" exact component={Home} />
                <Route path="/home" exact component={Home} />
                <Route path="/signup" exact component={RegisterForm}/>
                <Route path="/login" exact component={LoginForm} />
                <Route path="/homeuser" exact component={HomeUser} />
                <Route path="/enrolledcourse" exact component={EnrolledCourse}/>
                <Route path="/Java" exact component={Java} />
                <Route path="/Selenium" exact component={Selenium}/>
                <Route path="/Groovy" exact component={Groovy} />
                <Route path="/Python" exact component={Python}/>
                <Route path="/adminhome" exact component={AdminHome}/>
                <Route path="/about" component={About}/>
                <Route path="/CourseList" component={CourseList}/>
                <Route path="/certificate" exact component={Certificate}/>
                <Route path="/Users" component={Users}/>

                {/* <Route path="/login" exact component={LoginForm} render = {(props) => Login ={Login}}/> */}
                {/* <Route path="/login" exact component={LoginForm} render = {(props) => <LoginForm Login={Login} error ={error}/>}/> */}
                {/* <LoginForm Login={Login} error ={error}/> */}
                {/* {(user.email !="") ? (
        <div className="welcome">
          <h2> Welcome, <span> {user.name} </span></h2>
          <button onClick={Logout}>  Logout </button>
          </div>
      ) : (
            <LoginForm Login={Login} error ={error}/>
      )} */}
                
          </Switch>
      </Router>
    </div>
    <Footer/>
    </div>
  );
}

export default App;
