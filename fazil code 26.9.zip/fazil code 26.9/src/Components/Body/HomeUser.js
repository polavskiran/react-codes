import React, { useState,useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';

import axios from "axios";
import './Home.css';
import course1 from './reactjsimg.jpg'
import LoginForm from '../LoginForm';
import CourseDetails from '../GetCourses'
import NavbarUser from '../NavbarUser/NavbarUser'
// import Footer from '../Layout/Footer';

function HomeUser() {
  // const [user1, setUser] = useState({name: ""});
  // const HomeUser = ({user}) => {
  //   const YourRoute = props=> {
  //     const { _id, name } = (props.location && props.location.state) || {};
  //     console.log(name);
  // }
  useEffect(() => {
    userDetails()
},[]);
const history = useHistory();
      const location = useLocation();

        //console.log(useHistory());
         console.log(location.state); // result: 'some_value'
         const [result2, setResult2] = useState({result: ""});

         const userDetails = async () => {
           
         const resp2 = await axios.get(`http://10.208.66.112:8080/user/${location.state}`);
            setResult2(resp2.data);
            console.log(resp2.data);
            console.log(resp2.data.name);
            console.log(result2.name);


         }
  //   var data1 = `${user}`;
  //   setUser({user});
  //   return(
      
  //     <h2> {user.name} </h2>
  //   );
  // }

  // render() {
    return (
    //   <div>
    //   <img src={image} alt="image"  width = "1263" height = "300" />;

    //  <h1>Home page for HCL Trainee!</h1>;
    //  </div>
    
    <div>
      <NavbarUser/>
    <div class="background">
    {/* <a href="http://localhost:3000/login">Log Out</a> */}
      <div class="transbox-user">
        {/* <right><p><h2 className = "transbox-user">Logged In as {result2.name}</h2></p></right> */}
       </div>
       <div className="pagecontent">
         <p><h3>Learning Never Exhausts The Mind..</h3></p>
       </div>
    </div>
      {/* <div className="coursedetails">
    <img src={course1} alt="reactjs" width="300" height ="150" />
    <a herf="http://localhost:3000/signup">ReactJS</a>
    </div> */}
    {/* <table className ="homeUsertab">
    <th className="leftcell"><left><p><h2>Course we Offer...</h2></p></left></th>
    <th className="rightcell"><right><p><h2 className = "transbox-user">User Name: {result2.name}</h2></p></right></th></table> */}
    <h2>Course we Offer... &#160; &#160; &#160; &#160; &#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;
    &#160;&#160;&#160;&#160;
       User Name: {result2.name}</h2>
    <CourseDetails/>
    </div>
     )
     
    // <Footer/>
  }
// }
export default HomeUser;

// function Home() {
//     return (
//         <div>
//         <h1>Home page for HCL Trainee!</h1>;
//         </div>
//     );
//   }
//   export default Home;