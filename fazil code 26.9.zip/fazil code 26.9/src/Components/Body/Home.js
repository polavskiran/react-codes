import React from 'react';
import './Home.css';
import course1 from './reactjsimg.jpg'
import CourseDetails from '../GetCourses'
// import Footer from '../Layout/Footer';

class Home extends React.Component {


  render() {
    return (
    //   <div>
    //   <img src={image} alt="image"  width = "1263" height = "300" />;

    //  <h1>Home page for HCL Trainee!</h1>;
    //  </div>
    
    <div>
    <div class="background">
    <a href="http://localhost:3000/login">Log In</a>
      <div class="transbox">
        <p><center><h1 className="transbox">HCL TrainME</h1></center></p>
       </div>
    </div>
      {/* <div className="coursedetails">
    <img src={course1} alt="reactjs" width="300" height ="150" />
    <a herf="http://localhost:3000/signup">ReactJS</a>
    </div> */}
    <h2>Courses We Offer...</h2>
    <CourseDetails/>
    </div>
     )
     
    // <Footer/>
  }
}
export default Home;

// function Home() {
//     return (
//         <div>
//         <h1>Home page for HCL Trainee!</h1>;
//         </div>
//     );
//   }
//   export default Home;