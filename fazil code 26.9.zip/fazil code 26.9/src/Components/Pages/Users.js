import React from 'react'
import { useEffect, useState } from 'react';
import AdminNavbar from '../Navbar/Navbar'
import axios from 'axios';
import "./Table.css"

const Users = () => {
    const [Users, setUsers] = useState([]);
    // fires on component mounted and component updated.
    useEffect(() => {
        allCardData()
    },[]);
    // Fetch all data from API
    const allCardData = async () => {
        const  resp = await axios.get('http://10.208.66.112:8080/users');
        setUsers(resp.data);
    }
    return (
        <div >
            <AdminNavbar/>
             <br/>
             <br/>
             <br/>
             <br/>
              <center>  <table className="datatable">
                    <thead>
                        <tr>
                            <th>Employe ID</th>
                            <th>Name</th>
                            <th>Password</th>
                            <th>Role</th>
                       </tr>
                    </thead>
                    <tbody>
                        {
                            Users.map(User=>(
                                
                                <tr Key={User.empid} className={(User.roll % 2)? "odd_col":"even_col"}>
                                    <td>{User.empid}</td>
                                    <td>{User.name}</td>
                                    <td>{User.password}</td>
                                    <td>{User.roll}</td>
                                </tr>
                            ))
                        }
                    </tbody>
                </table></center>
        </div>
    )
}

export default Users;