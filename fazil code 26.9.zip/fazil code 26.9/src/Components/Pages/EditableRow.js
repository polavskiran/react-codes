import React from "react";
import "./Table.css"


const EditableRow = ({ editFormData, handleEditFormChange, handleCancelClick,}) => {
  return (
    <tr>
      <td>
        <input type="text"required="required" placeholder="Enter Course" name="coursename" value={editFormData.fullName}  onChange={handleEditFormChange}></input>
      </td>
      <td>
        <input type="text" required="required" placeholder="Enter author name" name="author" value={editFormData.address} onChange={handleEditFormChange} ></input>
      </td>
      <td>
        <input type="text" required="required" placeholder="Approx Duration" name="duration" value={editFormData.phoneNumber} onChange={handleEditFormChange}></input>
      </td>
      <td>
        <input type="text" required="required" placeholder="Short Description" name="description" value={editFormData.email} onChange={handleEditFormChange}></input>
      </td>
      <td>
      <button className="editablebutton" type="submit">Save</button>
       <button className="editablebutton" type="button" onClick={handleCancelClick}>
          Cancel
        </button>
      </td>
    </tr>
  );
};

export default EditableRow;