import React from "react";
import "./Table.css"
const ReadOnlyRow = ({ contact, handleEditClick, handleDeleteClick }) => {
  return (
    <tr>
      <td>{contact.coursename}</td>
      <td>{contact.author}</td>
      <td>{contact.duration}</td>
      <td>{contact.description}</td>
      <td>
        <button className ="editablebutton"
          type="button"
          onClick={(event) => handleEditClick(event, contact)}
        >
          Edit
        </button>
        <button className="editablebutton" type="button" onClick={() => handleDeleteClick(contact.id)}>
          Delete
        </button>
      </td>
    </tr>
  );
};

export default ReadOnlyRow;