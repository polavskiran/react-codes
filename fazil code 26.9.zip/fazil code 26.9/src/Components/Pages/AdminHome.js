import React from 'react'
import img from '../Images/hcltech.jpg';
import AdminNavbar from '../Navbar/Navbar'
import './AdminHome.css'

const AdminHome = () => {
    return (
        <div>
            <AdminNavbar/>
            <div className = "AdminHomebg">
                <div className="admincontent">
                    {/* <p><h3>Admin User</h3></p> */}
                </div>
            {/* <img className = "AdminHomebg" src={img} alt="" width="1260" height="500" /> */}

            </div>
        </div>
    )
}

export default AdminHome
