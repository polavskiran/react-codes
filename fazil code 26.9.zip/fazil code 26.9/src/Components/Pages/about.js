import React from 'react'
import img from '../Images/Image.jpg';
import AdminNavbar from '../Navbar/Navbar'
import './AdminHome.css'


const About = () => {
    return (
        <div className="AdminHomebg">
            <AdminNavbar/>
          <img className="AdminHomebg" src={img} alt=""/>
        </div>
    )
}

export default About
