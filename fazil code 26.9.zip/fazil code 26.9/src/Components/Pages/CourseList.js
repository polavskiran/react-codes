import React, { useState, Fragment } from "react";
import { nanoid } from "nanoid";
import "./Table.css";
import data from "./mock-data.json";
import AdminNavbar from '../Navbar/Navbar'
import ReadOnlyRow from "./ReadOnlyRow";
import EditableRow from "./EditableRow";

const CourseList2 = () => {
  const [contacts, setContacts] = useState(data);
  const [addFormData, setAddFormData] = useState({
    coursename: "",
    author: "",
    duration: "",
    description: "",
  });

  const [editFormData, setEditFormData] = useState({
    coursename: "",
    author: "",
    duration: "",
    description: "",
  });

  const [editContactId, setEditContactId] = useState(null);

  const handleAddFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...addFormData };
    newFormData[fieldName] = fieldValue;

    setAddFormData(newFormData);
  };

  const handleEditFormChange = (event) => {
    event.preventDefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;

    const newFormData = { ...editFormData };
    newFormData[fieldName] = fieldValue;

    setEditFormData(newFormData);
  };

  const handleAddFormSubmit = (event) => {
    event.preventDefault();

    const newContact = {
      id: nanoid(),
      coursename: addFormData.coursename,
      author: addFormData.author,
      duration: addFormData.duration,
      description: addFormData.description,
    };

    const newContacts = [...contacts, newContact];
    setContacts(newContacts);
  };

  const handleEditFormSubmit = (event) => {
    event.preventDefault();

    const editedContact = {
      id: editContactId,
      coursename: editFormData.coursename,
      author: editFormData.author,
      duration: editFormData.duration,
      description: editFormData.description,
    };

    const newContacts = [...contacts];

    const index = contacts.findIndex((contact) => contact.id === editContactId);

    newContacts[index] = editedContact;

    setContacts(newContacts);
    setEditContactId(null);
  };

  const handleEditClick = (event, contact) => {
    event.preventDefault();
    setEditContactId(contact.id);

    const formValues = {
      coursename: contact.coursename,
      author: contact.author,
      duration: contact.duration,
      description: contact.description,
    };

    setEditFormData(formValues);
  };

  const handleCancelClick = () => {
    setEditContactId(null);
  };

  const handleDeleteClick = (contactId) => {
    const newContacts = [...contacts];

    const index = contacts.findIndex((contact) => contact.id === contactId);

    newContacts.splice(index, 1);

    setContacts(newContacts);
  };

  return (
    <div className="app-container">
        <AdminNavbar/>
      <form onSubmit={handleEditFormSubmit}>
        <br/>
        <br/>
       <center> <table className="datatable">
          <thead>
            <tr>
              <th>Course Name</th>
              <th>Author</th>
              <th>Duration</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {contacts.map((contact) => (
              <Fragment>
                {editContactId === contact.id ? (
                  <EditableRow
                    editFormData={editFormData}
                    handleEditFormChange={handleEditFormChange}
                    handleCancelClick={handleCancelClick}
                  />
                ) : (
                  <ReadOnlyRow
                    contact={contact}
                    handleEditClick={handleEditClick}
                    handleDeleteClick={handleDeleteClick}
                  />
                )}
              </Fragment>
            ))}
          </tbody>
        </table></center>
        <br/>
      </form>
      <center>
     <h3>Add new course</h3>
      </center>
       <form onSubmit={handleAddFormSubmit}>
         <br/>
         <center>
        <div className="form-inner">
        <input type="text"name="coursename"required="required"placeholder="Enter Course.."onChange={handleAddFormChange}/>{" "}{" "}
        <input type="text" name="author"required="required"placeholder="Enter author name"onChange={handleAddFormChange}/>{" "}{" "}
        <input type="text"name="duration"equired="required"placeholder="Approx Duration"onChange={handleAddFormChange}/>{" "}{" "}
        <input type="txt" name="description"required="required"placeholder="Short description"onChange={handleAddFormChange}/><br/><br/>
        <button type="submit">Add</button> 
        </div>
        </center>
         </form>
    </div>
  );
};

export default CourseList2;