import React, {useState, useEffect} from 'react'
// import { Redirect } from 'react-router';
import { HashRouter, Router, useHistory, withRouter, Link, Route, Redirect } from 'react-router-dom';
import axios from "axios";
import './LoginForm.css';
import Home from './Body/Home';
import HomeUser from './Body/HomeUser'
import Switch from 'react-bootstrap/esm/Switch';

function LoginForm({ Login, error }) {

    

    const [details, setDetails] = useState({name: "", email: "", password: ""});

    const [result, setResult] = useState({result: ""});
    const [result2, setResult2] = useState({result: ""});
    const [user, setUser] = useState({name: ""});
    const [errorf, setErrorf] = useState("");
    

    useEffect(() => {
        loginUser()
    },[]);

    const adminUser = {
        email: "testuser@mail.com",
        password: "Password"
      }
    
      
    
    //   function Login(details) {
    //     console.log(details);

        const loginUser = async () => {
            const credential = { empid: details.email , password: details.password };
            const  resp = await axios.put('http://10.208.66.112:8080/signin', credential);
            setResult(resp.data);
            console.log(resp.data);
            const  resp2 = await axios.get(`http://10.208.66.112:8080/user/${details.email}`);
            setResult2(resp2.data);
            console.log(resp2.data);
            console.log(resp2.data.name);
            const dataname = resp2.data.name;
            setUser(resp2.data);
            // if(resp.data == true){
            //     alert(`login sucess for emp ID ${details.email}` );
                
            // } else{
            //    alert("Login failure"); 
            // }

            // axios.post('http://10.208.66.112:8080/signin', credential)
            //  .then(response => this.setState({ result: response.data}));
            //  console.log(response.data);
            // setRespLength(cardData.length);
            // console.log("Length is: "+respLength);
            // if (details.email == adminUser.email && details.password ==adminUser.password)
        if (details.email != "" && resp.data == "Success" && resp2.data.roll == "user"){
          console.log("Logged In");
            // alert(`login sucess for emp ID ${details.email}` );
        //   return <Redirect to='/home'/>
        // <HomeUser data = {}/>
            return history.push({
                pathname: '/homeuser',
                state: `${resp2.data.empid}`
                });
        //   return history.push(`/homeuser{name:${resp2.data.name}}`)
        //   return(
        //   <Redirect push to ='/home'/>
        //   )
        //   <Router>
        //       <Switch>
        //     <Route exact path="/home" component={Home} />
        //     </Switch>
        //     </Router>
        //   setUser({
        //     name: details.name,
        //     email: details.email
        //   });
        } else if(details.email != "" && resp.data == "Success" && resp2.data.roll == "admin"){
            return history.push({
                pathname: '/adminhome',
                state: `${resp2.data.empid}`
                });

        }else if(details.email!="" && resp.data == "Failed"){
            alert("Login failure, Incorrect Password"); 
            console.log("else gets executed");
          console.log("login details dint match");
            setErrorf("Login details dint match");
          console.log(errorf);
         } else if(details.email !="" && result.includes('No value present for')) {
            console.log("entered elseif")
            alert(`Login Failure, User ${details.email} is not Registered`);
            console.log(result);
            //console.log(`Failed , No value present for User ${details.email}`)
            
        }
      }
    

    const history = useHistory();
    
    // const routeChange = () =>{ 
    //     let path = "\signup"; 
    //     history.push(path);
    //   }


    const submitHandler = e => {
        e.preventDefault();
        loginUser(details);
    }

    return (
        <form className="loginform" onSubmit={submitHandler}>
            <div className="form-inner" >
                <h2><center>Login</center></h2> 
                
                {/* <div className="form-group">
                    <label htmlFor="name">Name:</label>
                    <input type="text" name="name" id="name" onChange={e => setDetails({...details, name: e.target.value})} value={details.name}/>
                </div> */}
                <center><div className="form-group">
                <label htmlFor="email">User ID:</label>
                    <input type="text" name="email" id="email" required onChange={e => setDetails({...details, email: e.target.value})} value={details.email}/>
                </div></center>
                <center><div className="form-group">
                <label htmlFor="password">Password:</label>
                    <input type="password" name="password" id="password" onChange={e => setDetails({...details, password: e.target.value})} value={details.password} /> 
                </div>
                {(errorf == "") ? (<div className="error">{errorf}</div>): ""}
                </center>
                <input className="loginbtn" type="submit" value="Login"/>
                <a className="loginbtn" href="http://localhost:3000/signup">Register</a>
                {/* <button className="loginbtn"><a href="http://localhost:3000/signup">Register</a></button> */}
                {/* <a data-purpose="header-login" href="http://localhost:3000/signup" 
                            className="rounded-corners"><span>Register</span></a> */}
                {/* <Link to="/signup">React</Link> */}
                {/* <button type="button" value="Register" onClick={routeChange}>Register</button> */}
                
            </div>
        </form>
    )
}

export default LoginForm

