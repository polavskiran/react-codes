// import React, {useState, useEffect} from 'react'
// // import { Redirect } from 'react-router';
// import { HashRouter, Router, useHistory, withRouter, Link, Route, Redirect } from 'react-router-dom';
// import axios from "axios";
// import './LoginNew.css';
// import Home from './Body/Home';
// import Switch from 'react-bootstrap/esm/Switch';

// function LoginForm({ Login, error }) {

    

//     const [details, setDetails] = useState({name: "", email: "", password: ""});

//     const [result, setResult] = useState({result: ""});
//     const [user, setUser] = useState({name: "" , email: "" });
//     const [errorf, setErrorf] = useState("");
    

//     useEffect(() => {
//         loginUser()
//     },[]);

//     // const adminUser = {
//     //     email: "testuser@mail.com",
//     //     password: "Password"
//     //   }
    
      
    
//     //   function Login(details) {
//     //     console.log(details);

//         const loginUser = async () => {
//             const credential = { empid: details.email , password: details.password };
//             const  resp = await axios.put('http://10.208.66.112:8080/signin', credential);
//             setResult(resp.data);
//             console.log(resp.data);
            
//             // if(resp.data == true){
//             //     alert(`login sucess for emp ID ${details.email}` );
                
//             // } else{
//             //    alert("Login failure"); 
//             // }

//             // axios.post('http://10.208.66.112:8080/signin', credential)
//             //  .then(response => this.setState({ result: response.data}));
//             //  console.log(response.data);
//             // setRespLength(cardData.length);
//             // console.log("Length is: "+respLength);
//             // if (details.email == adminUser.email && details.password ==adminUser.password)
//         if (details.email != "" && resp.data == true){
//           console.log("Logged In");
//             // alert(`login sucess for emp ID ${details.email}` );
//         //   return <Redirect to='/home'/>
//           return history.push("/home") 
//         //   return(
//         //   <Redirect push to ='/home'/>
//         //   )
//         //   <Router>
//         //       <Switch>
//         //     <Route exact path="/home" component={Home} />
//         //     </Switch>
//         //     </Router>
//         //   setUser({
//         //     name: details.name,
//         //     email: details.email
//         //   });
//         } else if(details.email!=""){
//             alert("Login failure"); 
//             console.log("else gets executed");
//           console.log("login details dint match");
//             setErrorf("Login details dint match");
//           console.log(errorf);
//           return <Redirect to='http://localhost:3000/home'  />
//         }
//       }
    

//     const history = useHistory();
    
//     // const routeChange = () =>{ 
//     //     let path = "\signup"; 
//     //     history.push(path);
//     //   }

//     const submitHandler = e => {
//         e.preventDefault();
//         loginUser(details);
//     }

//     return (
//         <div className="login">
//   <h1>Login</h1>
//     <form onSubmit={submitHandler} method="post">
//       <input type="text" name="u" placeholder="Username" required="required" onChange={e => setDetails({...details, email: e.target.value})} value={details.email} />
//         <input type="password" name="p" placeholder="Password" required="required"onChange={e => setDetails({...details, password: e.target.value})} value={details.password}/>
//         <button type="submit" class="btn btn-primary btn-block btn-large">Log In</button>
//     </form>
// </div>
        

            
            
//                 // <input type="submit" value="Login"/>
//                 // <button onClick="http://localhost:3000/signup"><a href="http://localhost:3000/signup">Register</a></button>
                

//     )
// }

// export default LoginForm

