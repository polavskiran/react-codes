import React from 'react';
import * as ReactBootStrap from 'react-bootstrap';
import './Header.css';
import { Dropdown } from 'react-bootstrap';
import CustomSelect from './CustomSelect';

const Header = ()=> {
    return (       
        <div className="main-header">
            <table>
                <tr>
                    <th className="col1" >
                        <h1>TrainMe</h1>  
                    </th>
                    <th className="col2">
                        <h1>
                        <CustomSelect/>
                            {/* <select className="dropdown" onChange={(e) => this.setState({productPrice: e.target.value})}>
                                <option value="0">Select Courses</option>
                                <option value="1">Java8</option>
                                <option value="2">ReactJS</option>     
                                <option value="3">Python</option>     
                                <option value="4">Grroovy</option>                                                               
                            </select> */}
                        </h1>
                    </th>
                    <th  className="col3">
                        <h1 className="col3"><input type="text" placeholder="Search for any courses" name="q" autocomplete="off" value="" role="combobox" aria-autocomplete="both" aria-haspopup="true" aria-expanded="false" aria-controls="u521-search-form-autocomplete--3-menu-content-items" id="u521-search-form-autocomplete--3" className="udlite-text-input udlite-text-input-small udlite-text-sm udlite-search-form-autocomplete-input js-header-search-field rounded-corners-for-searchbox"/></h1>        
                    </th>
                    <th className="col4">
                            <a data-purpose="header-login" href="/login" 
                            className="rounded-corners"><span>Log in</span></a>
                            {/* <a data-purpose="header-login" href="https://www.udemy.com/join/login-popup/?locale=en_US&amp;response_type=html&amp;next=https%3A%2F%2Fwww.udemy.com%2Fjoin%2Flogin-popup%2F%3Flocale%3Den_US%26response_type%3Dhtml%26next%3Dhttps%253A%252F%252Fwww.udemy.com%252Fjoin%252Flogin-popup%252F%253Fnext%253D%252Fuser%252Fedit-profile%252F" 
                            className="rounded-corners"><span>Log in</span></a> */}

                    </th>
                </tr>
            </table>
        </div>
    );
  }
  export default Header;