import React, {useEffect, useState} from "react";
import Select from 'react-select';
import axios from 'axios';
import './CustomSelect.css'
 
 
function CustomSelect(onChange,defaultValue){
   
    const [selectData, setSelectData] = useState([]);
    
    // fires on component mounted and component updated.
    useEffect(() => {
        allCardData()
    },[]);
 
    // Fetch all data from API
    const allCardData = async () => {
        const  resp = await axios.get('http://10.208.66.112:8080/course');
 
        const newArray =[]; 
        for (const [key, value] of Object.entries(resp.data)) {
            const obj = {'label':value.bookname, 'value':value.bookid};
            newArray.push(obj);
            console.log(key+" : "+value.bookid+" : "+ value.bookname);
 
        }
     
        setSelectData(newArray);
  
    }
 
    return <div >
                <Select  placeholder="Select courses" options={selectData} onChange={onChange} defaultValue={defaultValue}/>
           </div>
 
}
export default CustomSelect;