import React from 'react';
import * as ReactBootStrap from 'react-bootstrap';
import './Footer.css';

const Footer = ()=> {
    return (       
        <div className="main-footer">
            <div className="container" >
                {/* <div className="row" >
                    
                    <div className="col" >
                        <h4>Top Tutorials</h4>
                        <ul className="list-unstyled">
                            <li>HTML Tutorial</li>
                            <li>CSS Tutorial</li>
                            <li>JavaScript Tutorial</li>
                        </ul>
                    </div>
                   
                    <div className="col" >
                        <h4>Top References</h4>
                        <ul className="list-unstyled">
                            <li>HTML Reference</li>
                            <li>CSS Reference</li>
                            <li>JavaScript Reference</li>
                        </ul>
                    </div>
                    
                    <div className="col" >
                        <h4>Top Examples</h4>
                        <ul className="list-unstyled">
                            <li>HTML Examples</li>
                            <li>CSS Examples</li>
                            <li>JavaScript Examples</li>
                        </ul>
                    </div>
                   
                    <div className="col" >
                        <h4>Web Courses</h4>
                        <ul className="list-unstyled">
                            <li>HTML Course</li>
                            <li>CSS Course</li>
                            <li>JavaScript Course</li>
                        </ul>
                    </div>
                </div> */}
                <div className="row">
                    <p className="col-sm"> © 2021 HCL Technologies. All rights reserved.</p>
                </div>
            </div>
        </div>
    );
  }
  export default Footer;