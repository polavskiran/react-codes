import React, {useEffect,useState} from 'react';
import axios from "axios";
import {Nav,NavLink,Bars,NavMenu,NavBtn,}from './NavbarElementsUser';
import { useHistory, useLocation } from 'react-router-dom';
import './Navbar.css';



const Navbar = () => {

   

    useEffect(() => {
        userDetails()
    },[]);
    const history = useHistory();
          const location = useLocation();
    
            //console.log(useHistory());
             console.log(location.state); // result: 'some_value'
             const [result2, setResult2] = useState({result: ""});
    
             const userDetails = async () => {
               
             const resp2 = await axios.get(`http://10.208.66.112:8080/user/${location.state}`);
                setResult2(resp2.data);
                console.log(resp2.data);
                console.log("this is from Nav bar");
                console.log(resp2.data.name);
                console.log(result2.name);
    
    
             }
    
const enrolluserID = () => {

    return history.push({pathname: '/enrolledcourse', state: `${result2.empid}`});
}

    return (
        <>
            <Nav>
                <NavLink to="/">
                    <h2 align="right">HCL TrainME</h2>
                </NavLink>
                <Bars />
                <NavMenu className ="menubaruser" >
                    <NavLink className ="buttonMenu" to="/about"activeStyle>
                    About
                    </NavLink>
                    {/* <NavLink className ="buttonMenu" to="/CourseList"activeStyle>
                        Courses
                    </NavLink> */}
                    <NavLink className ="buttonMenu" to="/enrolledcourse"activeStyle onClick={enrolluserID}>
                       Enrolled Courses
                    </NavLink>
                    <NavBtn>
                    <NavLink className="buttonMenu"to="/login"activeStyle>
                        Logout
                    </NavLink>
                    </NavBtn>
                </NavMenu>
            </Nav>
        </>
    )
}

export default Navbar
