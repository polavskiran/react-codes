import React, { useState,useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import axios from "axios";
import './certificate.css';
import NavbarUser from './NavbarUser/NavbarUser'

function Certificate() {
    useEffect(() => {
        userDetails()
      },[]);

      const [result2, setResult2] = useState({result: ""});
      const history = useHistory();
            const location = useLocation();
      const userDetails = async () => {
        const resp2 = await axios.get(`http://10.208.66.112:8080/user/${location.state}`);
           setResult2(resp2.data);
           console.log(resp2.data);
           console.log(resp2.data.name);
           console.log(result2.name);
      
        }
    console.log("Certificate generated.");

  return (
      <div>
          <NavbarUser/>
   <center> <div className="certificate-container">
        
        <div className="certificate">
            <div className="water-mark-overlay"></div>
            {/* <div className="certificate-header">
                <img src="https://rnmastersreview.com/img/logo.png" className="logo" alt=""></img>
            </div> */}
            <div className="certificate-body">

                <p className="certificate-title"><strong>TrainMe Application</strong></p>
                <h1>Certificate of Course Completion</h1>
                <h2>This Certificate is presented to</h2>
                <p className="student-name">{result2.name}</p>
                <div className="certificate-content">                    
                    <p className="topic-title">
                        For completing 1-month course training in Java Programming.
                    </p>
                    <div className="text-center">
                    </div>
                </div>
                <div className="certificate-footer text-muted">
                    <div className="row">
                        <div className="col-md-6">
                            <p>Manager: Subramoniam AB </p>
                        </div>
                        {/* <div className="col-md-6">
                            <div className="row">
                                <div className="col-md-6">
                                    <p>
                                        Accredited by
                                    </p>
                                </div>
                                <div className="col-md-6">
                                    <p>
                                        Endorsed by
                                    </p>
                                </div>
                            </div>
                        </div> */}
                    </div>
                </div>
            </div>
        </div>
    </div></center>
    </div>
  );
}

export default Certificate;