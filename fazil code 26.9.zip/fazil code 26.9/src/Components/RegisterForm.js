import React,{useState, useEffect} from 'react'
import { HashRouter, Router, useHistory, withRouter, Link, Route, Redirect } from 'react-router-dom';
import axios from "axios";
import './LoginForm.css'

function RegisterForm({ SignUp, error }) {
    const [details, setDetails] = useState({empid: "", name: "", password: "", roll:'user'});
    const [result, setResult] = useState({result: ""});

    useEffect(() => {
        signup()
    },[]);

    const signup = async () => {
        const credential = { empid: details.empid , name: details.name, password: details.password, roll: details.roll };
        const  resp = await axios.post('http://10.208.66.112:8080/register', credential);
        setResult(resp.data);
        console.log(resp.data);
    
    }
    const userdata = async () => {
        let emp=details.empid;
        const credential = { empid: details.empid , name: details.name, password: details.password, roll: details.roll };
        const  resp2 = await axios.get(`http://10.208.66.112:8080/user/${details.empid}`);
        //const  resp2 = await axios.get('http://10.208.66.112:8080/users');
        setResult(resp2.data);
        console.log(resp2.data);
        console.log(resp2.data.name);
    

    if(details.name == resp2.data.name){
        alert(`You are sucessfully Signed Up as ${resp2.data.name}` );
        return history.push("/login") 

    }
}

    const history = useHistory();
    
    const registerHandler = e => {
        e.preventDefault();

        signup(details);
        userdata(details);
    }


    return (
        <form className="loginform" onSubmit={registerHandler}>
            <div className="form-inner">
                
                <h2><center>Sign Up</center></h2>
                <center><div className="form-group">
                    <label htmlFor="empid">User ID:</label>
                    <input type="text" name="empid" id="empid" onChange={e => setDetails({...details, empid: e.target.value})} value={details.empid}/>
                </div>
                <div className="form-group">
                <label htmlFor="name">Name:</label>
                    <input type="text" name="name" id="name" onChange={e => setDetails({...details, name: e.target.value})} value={details.name}/>
                </div>
                <div className="form-group">
                <label htmlFor="password">Password:</label>
                    <input type="password" name="password" id="password" onChange={e => setDetails({...details, password: e.target.value})} value={details.password} /> 
                </div>
                <div className="form-group">
                <label htmlFor="roll">Role:</label>
                    <input type="text" name="roll" id="roll" placeholder="User" value="user" disabled onClickCapture={e => setDetails({...details, roll: e.target.value})} value={details.roll} /> 
                </div>
                </center>
              <center> <input className="loginbtn" type="submit" value="SignUp"/></center>
               
            </div>
        </form>
    )
}

export default RegisterForm
