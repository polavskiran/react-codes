import Styled from 'styled-components'
import { NavLink as NavLink1 } from 'react-router-dom'
import { FaBars } from 'react-icons/fa'


export const Nav = Styled.nav`
background: #000;
  height: 80px;
  display: flex;
  justify-content: space-between;
  padding: 0.5rem calc((100vw - 1000px) /2);
  Z-index: 10;
`
export const Nav2 = Styled.nav`
background:  rgb(117, 201, 250);
  height: 40px;
  padding:1 rem;
 
`
export const NavLink = Styled(NavLink1)`
 color: #fff;
 display: flex;
 align-items: center;
 text-decoration: none;
 padding: 1 rem;
 height: 100%;
 cursor: pointer;

 &.active {
     color: #15cdfc;
 }
`

export const Bars = Styled(FaBars)`
 display: none;
 color: #fff;

 @media screen and (max-width: 768px){
     display: block;
     position: absolute;
     top: 0;
     right: 0;
     transform: translated(-100%,75%)
     font-size: 1.8rem;
     cursor: pointer;
 }
`
export const NavMenu = Styled.div`
 display: flex;
 align-items: center;
 margin-right: -24px;
 @media scren and (max-width: 768px){
     display: none;
 }
`
export const NavBtn = Styled.nav`
`
//  display: flex;
//  align-items: center;
//  margin-right: 24px;
//  @media scren and (max-width: 768px){
//      display: none;
//  }
// `


// export const NavBtnLink = Styled(NavLink1)`
//  border-radius: 4px;
//  background: #256ce1;
//  padding: 10px 22px;
//  color: #fff;
//  border: none;
//  outline: none;
//  cursor: pointer;
//  transition: all 0.2s ease-in-out;
//  text-decoration: none;

//  margin-left: 24px;

//  &: hover{
//     transition: all 0.2s ease-in-out;
//      background: #fff;
//      color: #010606
//  }

 
 
// `

;


