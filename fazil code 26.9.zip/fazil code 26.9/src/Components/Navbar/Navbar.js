import React from 'react';
import {Nav,NavLink,Bars,NavMenu,NavBtn,}from './NavbarElements';
import '../Admin.css';


const Navbar = () => {
    return (
        <>
            <Nav>
                <NavLink to="/">
                    <h1>HCL TrainME</h1>
                </NavLink>
                <Bars />
                <NavMenu>
                    <NavLink className ="buttonMenu" to="/about"activeStyle>
                    About
                    </NavLink>
                    <NavLink className ="buttonMenu" to="/CourseList"activeStyle>
                        Courses
                    </NavLink>
                    <NavLink className ="buttonMenu" to="/Users"activeStyle>
                       Users
                    </NavLink>
                    <NavBtn>
                    <NavLink className="buttonMenu"to="/login"activeStyle>
                        Logout
                    </NavLink>
                    </NavBtn>
                    <div className="adminname"> Admin </div>
                </NavMenu>
            </Nav>
        </>
    )
}

export default Navbar
