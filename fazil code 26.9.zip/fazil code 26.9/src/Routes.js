import React from 'react';
import { BrowserRouter as Switch, Route, Link} from 'react-router-dom';
import Home from './Components/Body/Home';
import LoginNew from './Components/LoginNew'
import LoginForm from './Components/LoginForm';
import RegisterForm from './Components/RegisterForm';

const Routes = ({ props })=>{
    return(         
             <Switch>
                  <Route path="/" exact component={Home} />
                  <Route path="/login" exact component={LoginForm} />
                  <Route path="/signup" exact component={RegisterForm} />
             </Switch>
    );
};