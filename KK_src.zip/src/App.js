import logo from './logo.svg';
import './App.css';
import GetCourses from './Components/GetCourses';
import CourseDetails from './Components/CourseDetails';
import Certificate from './Components/Certificate';
import './Components/certify.css';

function App() {
  return (
    <div className="App">

      <GetCourses />
    </div>
  );
}

export default App;
