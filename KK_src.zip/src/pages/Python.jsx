import React, {useState} from "react";
import CourseDetails from "../Components/CourseDetails";

function PythonCourseDetails(){

    function generateCerticate(){
        alert('Certificate Completed');

        // Hareesh Code
    }

    return(
        <>
            <div>
                <header>
                    Java Course
                </header>
                <hr />
                <body>
                    <div className="">
                    Java is a high-level, class-based, object-oriented programming language 
                    that is designed to have as few implementation dependencies as possible.
                    </div>
                    <hr />
                    <div>
                        <button onClick={generateCerticate}>Complete</button>
                    </div>                    
                </body>
            </div>
        </>
    );
}

export default PythonCourseDetails;