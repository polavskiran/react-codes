import React, {useState} from "react";
import Certificate from "../Components/Certificate";
import CourseDetails from "../Components/CourseDetails";
import {BrowserRouter as Router, Route, Link, Switch, useHistory} from "react-router-dom";
import Hello from "./Hello";
import { Redirect } from "react-router-dom/cjs/react-router-dom.min";

function JavaCourseDetails(){

    const [showCertificate, setShowCertificate] = useState(false);
    let history = useHistory ();

    function generateCerticate(){

        setShowCertificate(true);
    }

    return(
        <>
            <div>
                <header>
                    Java Course
                </header>
                <hr />
                <div className="">
                    Java is a high-level, class-based, object-oriented programming language 
                    that is designed to have as few implementation dependencies as possible.
                    </div>
                    <hr />
                    <div>
                        <button onClick={generateCerticate}>Complete</button>
                    </div>
                    <div id="certificate">

                        {showCertificate === true ? history.push("/pages/Hello") : null}
                    </div>
            </div>
        </>
    );
}

export default JavaCourseDetails;