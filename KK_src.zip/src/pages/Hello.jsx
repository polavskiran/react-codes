import Certificate from "../Components/Certificate";

function Hello(){
    return(
        <Certificate />
    );
}

export default Hello;