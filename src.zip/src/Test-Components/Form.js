import React from "react";
import './newStyles.css';

class Form extends React.Component {

    constructor(props){
        super(props);
        this.state = {
            firstName : '',
            comments : ''
        };        
    }    

    changeFirstName = (event) => {
        this.setState({
            firstName : event.target.value
        });
    }

    handleCommentsChange = (event) => {
        this.setState({
            comments : event.target.value
        });
    }

    handleUpdate = (event) => {
        event.preventDefault();
        alert(this.state.firstName+','+this.state.comments);
    }

    render() {        
        const {firstName,comments} = this.state;
        return(
            <form onSubmit={this.handleUpdate}>
                <div className='center'>
                    <h2>Sample Form</h2>
                    <label>User Name: </label>
                    <input type="text" value={firstName} onChange={this.changeFirstName} /><br />
                    <hr />
                    <label>Comments: </label>
                    <textarea rows="4" cols="23" value={comments} onChange={this.handleCommentsChange}></textarea>
                </div>
                <div className='center'>
                    <button type="submit">Submit</button>
                </div>
            </form>
        );
    }
}

export default Form;