import React from "react";

function DisplayProfiles() {

    const testData = [
        {name: "Daniel", avatar_url: "https://avatars0.githubusercontent.com/u/810438?v=4", company: "Intel"},
        {name: "Sophie", avatar_url: "https://avatars2.githubusercontent.com/u/6820?v=4", company: "Facebook"},
        {name: "Sebastian", avatar_url: "https://avatars2.githubusercontent.com/u/63648?v=4", company: "Twitter"}
    ];

    const CardList = () => (
        <div>
            {testData.map(profile => <Card {...profile} />)}
        </div>
    );

    // Create a Card component
    function Card(props) {
        const profile = props;
        return(
            <div>
                <img alt={""} src={profile.avatar_url} />
                <div>
                    <div>Name: {profile.name}</div>
                    <div>Company: @{profile.company}</div>
                </div>
            </div>
        );
    }

    return(
        <div>            
            <CardList />
        </div>
    );
}

export default DisplayProfiles;