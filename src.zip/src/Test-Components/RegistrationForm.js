import React from "react";
import { useState } from "react/cjs/react.development";

function RegistrationForm(){

    const [values, setValues] = useState({
        firstName : "",
        lastName : "",
        email : ""
    });

    const handleFirstNameInputChange = (event) =>{
        setValues({...values, firstName: event.target.value});
    }

    const handleLastNameInputChange = (event) =>{
        setValues({...values, lastName: event.target.value});
    }

    const handleEmailInputChange = (event) =>{
        setValues({...values, email: event.target.value});
    }

    const [submitted, setSubmitted] = useState(false);
    const [valid, setValid] = useState(false);

    const handleSubmitForm = (event) => {
        event.preventDefault();
        //const {firstName, lastName, email} = values;
        if(values.firstName && values.lastName && values.email){
            setValid(true);
        }
        setSubmitted(true);
    }

    return(
        <>
            <form onSubmit={handleSubmitForm}>
                <div className="center">
                    <h2> Registration Form </h2>
                </div>
                <div className="divform center">
                    {submitted && valid ? <div>Success! Thank for Registering!</div> : null}
                    <input type="text" name="firstName" placeholder="First Name"
                        onChange={handleFirstNameInputChange} value={values.firstName} />
                    {submitted && !values.firstName ? <span>Please Enter First Name </span> : null}
                    <br />

                    <input type="text" name="lastName" placeholder="Last Name"
                        onChange={handleLastNameInputChange} value={values.lastName} />
                    {submitted && !values.lastName ? <span>Please Enter Last Name </span> : null}
                    <br />

                    <input type="text" name="Email" placeholder="Email Address"
                        onChange={handleEmailInputChange} value={values.email} />
                    {submitted && !values.email ? <span>Please Enter Email Address</span> : null}
                    <br />
                    <button type="submit">Register</button>
                </div>
            </form>
        </>
    );
}

export default RegistrationForm;