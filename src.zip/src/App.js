import logo from './logo.svg';
import './App.css';
import GetCourses from "./components/GetCourses";
import "bootstrap/dist/css/bootstrap.min.css"
import CourseDetails from "./components/CourseDetails";
import ParentComponent from "./Test-Components/ParentComponent";

function App() {
  return (
    <div className="App">

        <GetCourses />
    </div>
  );
}

export default App;