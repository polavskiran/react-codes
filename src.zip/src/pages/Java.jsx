import React, {useState} from "react";
import CourseDetails from "../components/CourseDetails";

function JavaCourseDetails(){

    return(
        <>
            <div>
                <CourseDetails showDetails={true} />
            </div>
        </>
    );
}

export default JavaCourseDetails;