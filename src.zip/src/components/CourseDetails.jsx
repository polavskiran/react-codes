import React, {useState} from "react";
import {Button, Modal} from "react-bootstrap";

function CourseDetails(props){

    console.log(props.showModel);
    const [show,setShow] = useState(false);
    console.log("CourseDetails Page");
    const [enrollCourse, setEnrollCourse] = useState(false);
    const [completeSucceess, setCompleteCourse] = useState(false);

    if(props.showModel){
        setShow(true);
    }

    function enrollSuccess(){
        return(
            document.getElementById('msg-success').innerText = "Enrolled Successfully",
            document.getElementById('msg-complete').innerText = ""
        );
    }

    function completeCourse(){
        return(
            document.getElementById('msg-complete').innerText = "Course Completed Successfully",
            document.getElementById('msg-success').innerText = ""
        );
    }

    function closeModal(){
        setShow(false);
    }

    return(
        <>
            <div className="modal-dialog">
                <Modal show={show} onHide={closeModal}>
                    <Modal.Header closeButton>Java Course</Modal.Header>
                    <div id="msg-success"></div>
                    <div id="msg-complete"></div>
                    <Modal.Body>
                        Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.
                    </Modal.Body>
                    <Modal.Footer>
                        <Button onClick={enrollSuccess}>Enroll</Button>
                        <Button onClick={completeCourse}>Complete</Button>
                        <Button onClick={closeModal}>Close</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        </>
    );
}

export default CourseDetails;