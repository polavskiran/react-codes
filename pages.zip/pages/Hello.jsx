import Certificate from "../components/Certificate";


function Hello(){
    return(
        <Certificate />
    );
}

export default Hello;