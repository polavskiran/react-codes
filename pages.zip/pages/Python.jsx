import React, {useState} from "react";
import {useHistory} from "react-router-dom";
import Certificate from "../components/Certificate";

function PythonCourseDetails(){

    const [showCertificate, setShowCertificate] = useState(false);
    let history = useHistory ();

    function generateCertificate() {

        setShowCertificate(true);
    }

    function getCourseDetails(){

    }

    function saveCourse(){
    }


    return(
        <>
            <form onSubmit={saveCourse}>
                <div>
                    <div className="courseImg" >
                        <img src={process.env.PUBLIC_URL +`/images/Python-Programming.png`} style={{width: "450px",height: "200px"}} />
                    </div>
                    <br />
                    <div className="course-desc">
                        <strong>Learn Python like a Professional Start from the basics and go all the way to creating your own applications and games</strong>
                        <ol className="c">
                            <li>Learn to use Python professionally, learning both Python 2 and Python 3!</li>
                            <li>Create games with Python, like Tic Tac Toe and Blackjack!</li>
                            <li>Learn advanced Python features, like the collections module and how to work with timestamps!</li>
                        </ol>
                    </div>
                    <div>
                        <button type="submit">Enroll</button>
                    </div>
                    <div id="certificate">
                        {showCertificate === true ? <Certificate /> : null}
                    </div>
                </div>
            </form>
        </>
    );
}

export default PythonCourseDetails;