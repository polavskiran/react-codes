import React, {useState} from "react";
import {useHistory} from "react-router-dom";
import Certificate from "../components/Certificate";

function GroovyCourseDetails(){

    const [showCertificate, setShowCertificate] = useState(false);
    let history = useHistory ();

    function generateCertificate() {

        setShowCertificate(true);
    }

    return(
        <>
            <div>
                <div className="courseImg" >
                    <img src={process.env.PUBLIC_URL +`/images/Groovy.png`} style={{width: "450px",height: "200px"}} />
                </div>
                <div className="course-desc">
                    <strong>Apache Groovy is a Java-syntax-compatible object-oriented programming language for the Java platform. <br/>
                        It is both a static and dynamic language with features similar to those of Python, Ruby, and Smalltalk.</strong>
                    <ol className="c">
                        <li>Create Groovy Applications from Scratch</li>
                        <li>Use the Groovy Console</li>
                        <li>Write Groovy Applications in IntelliJ</li>
                    </ol>
                </div>
                <div>
                    <button onClick={generateCertificate}>Enroll</button>
                </div>
                <div id="certificate">
                    {showCertificate === true ? <Certificate /> : null}
                </div>
            </div>
        </>
    );
}

export default GroovyCourseDetails;