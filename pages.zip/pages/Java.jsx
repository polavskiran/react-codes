import React, {useState} from "react";
import {useHistory, useParams} from "react-router-dom";
import axios from "axios";
import Certificate from "../components/Certificate";

function JavaCourseDetails(){

    const [showCertificate, setShowCertificate] = useState(false);
    let history = useHistory ();
    const { id,emp_id } = useParams();

    const getCourseDetails = async () => {
        fetchCourseDetail();
    }

    const fetchCourseDetail = async () => {

        console.log(`http://10.208.66.112:8080/course/${id}`);
        const resp_course = await axios.get(`http://10.208.66.112:8080/course/${id}`);

        console.log(resp_course);
    }

    const enrollCourse = async () => {
        console.log(id+" : "+emp_id);
        const courseDetails = {course_id: id, emp_id: emp_id};
        const resp = await axios.post('http://10.208.66.112:8080/enrolling', courseDetails);

        console.log(resp);
    }

    function saveCourse(e) {
        console.log(id+" : "+emp_id);
        e.preventDefault();

        getCourseDetails();
        enrollCourse();
    }

    function generateCertificate() {
        setShowCertificate(true);
    }

    return(
        <>
            <form onSubmit={saveCourse}>
                <div>
                    <div className="courseImg">
                        <img src={process.env.PUBLIC_URL +`/images/Java-Course.jpg`} style={{width: "450px",height: "200px"}} />
                    </div>
                    <div className="course-desc">
                        <strong>Java is a high-level, class-based, object-oriented programming language <br/>
                            that is designed to have as few implementation dependencies as possible.</strong>

                        <ol className="c">
                            <li>Gain in-depth understanding of core & advanced features of Java including JVM internals</li>
                            <li>Master design principles, best practices and coding conventions for writing well-designed, professional Java code</li>
                            <li>Get real-world experience by developing an instructor-led Java EE-based Web application using technologies like JSP, Servlets and MySQL</li>
                        </ol>
                    </div>
                    <div>
                        <button type="submit">Enroll</button>
                    </div>
                    <div id="certificate">
                        {showCertificate === true ? <Certificate /> : null}
                    </div>
                </div>
            </form>
        </>
    );
}

export default JavaCourseDetails;