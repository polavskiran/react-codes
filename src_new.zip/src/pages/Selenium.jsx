import React, {useState} from "react";
import {useHistory} from "react-router-dom";
import Certificate from "../components/Certificate";

function SeleniumCourseDetails(){

    const [showCertificate, setShowCertificate] = useState(false);
    let history = useHistory ();

    function generateCertificate() {

        setShowCertificate(true);
    }

    return(
        <>
            <div>
                <div className="courseImg">
                    <img src={process.env.PUBLIC_URL +`/images/Selenium.png`} style={{width: "450px",height: "200px"}} />
                </div>
                <br />
                <div>
                    <strong>Build Your Own Automation Framework And Learn Everything About Selenium WebDriver. Zero Previous Knowledge Required.</strong>
                    <ul>
                        <li>Create a Selenium Webdriver framework from scratch using Java.</li>
                        <li>By the end of this course,You will be Mastered on Selenium Webdriver with strong Core Java basics.</li>
                        <li>You will gain the ability to design Page Object, DataDriven & Hybrid Automation Frameworks from scratch.</li>
                    </ul>
                </div>
                <div>
                    <button onClick={generateCertificate}>Enroll</button>
                </div>
                <div id="certificate">
                    {showCertificate === true ? <Certificate /> : null}
                </div>
            </div>
        </>
    );
}

export default SeleniumCourseDetails;