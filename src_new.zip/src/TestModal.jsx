import React, { useEffect, useRef, useState } from "react";
import Modal from "react-modal";
//import "./styles.css";

const modalStyle = {
    content: {
        backgroundColor: "#00000022",
        top: "50%",
        left: "50%",
        right: "auto",
        bottom: "auto",
        marginRight: "-50%",
        transform: "translate(-50%, -50%)",
        width: "50vw",
        height: "50vh",
        textAlign: "center"
    }
};

Modal.setAppElement("#root");

const useHover = () => {
    const ref = useRef();
    const _ref = useRef();
    const [hovered, setHovered] = useState(false);
    const enter = () => setHovered(true);
    const leave = () => setHovered(false);

    useEffect(() => {
        if (ref.current) {
            _ref.current = ref.current;
            _ref.current.addEventListener("mouseenter", enter);
            _ref.current.addEventListener("mouseleave", leave);
        }

        return () => {
            if (_ref.current) {
                _ref.current.removeEventLisener("mouseenter", enter);
                _ref.current.removeEventLisener("mouseleave", leave);
            }
        };
    }, []);

    return [ref, hovered];
};

export default function TestModal() {
    const [ref, hovered] = useHover();

    return (
        <div className="App">
            <h1>Hello CodeSandbox</h1>
            <h2>Start editing to see some magic happen!</h2>

            <h2 ref={ref}>Hover me</h2>

            <div>Hovered: {hovered ? "hovered" : "unhovered"}</div>

            <Modal isOpen={hovered} style={modalStyle}>
                <h2>The Modal</h2>
                <div>I am a modal</div>
            </Modal>
        </div>
    );
}
