import React, {useEffect, useState} from "react";
import CourseDetails from "./components/CourseDetails";

function EventDemo() {

    const [showModal, setShowModal] = useState(false);

    return(
      <>
          <div>
              <button onMouseEnter={() => setShowModal(true)} id="display">Display</button>
              <div id="modal-details">
                  {showModal === true ? <CourseDetails open="true" /> : null}
              </div>
          </div>
      </>
    );
}

export default EventDemo;