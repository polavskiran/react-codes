import logo from './logo.svg';
import './App.css';
import GetCourses from "./components/GetCourses";
import "bootstrap/dist/css/bootstrap.min.css"
import JavaCourseDetails from "./pages/Java";
import PythonCourseDetails from "./pages/Python";
import GroovyCourseDetails from "./pages/Groovy";
import SeleniumCourseDetails from "./pages/Selenium";
import Hello from "./pages/Hello";
import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

function App() {
    return (
        <div className="App">
            <Router>
                <Switch>
                    <Route path="/" exact component={GetCourses} />
                    <Route path="/Java/:id/:emp_id" exact component={JavaCourseDetails} />
                    <Route path="/Python" exact component={PythonCourseDetails}/>
                    <Route path="/Groovy" exact component={GroovyCourseDetails}/>
                    <Route path="/Selenium" exact component={SeleniumCourseDetails}/>
                    <Route path="/Hello" exact component={Hello}/>

                </Switch>
            </Router>
        </div>
    );
}

export default App;