import React, { useState } from "react";
import ChildComponent from "./ChildComponent";
import './newStyles.css';

function ParentComponent() {

    const [parentName, setParentName] = useState('Kiran');

    function greetParent(){
        setParentName(parentName => parentName + ' Kumar')
        alert(`Hello, ${parentName}`);
    }

    return(
        <div className='center'>
            <ChildComponent greetHandler={greetParent}/>
        </div>
    );
}

export default ParentComponent;