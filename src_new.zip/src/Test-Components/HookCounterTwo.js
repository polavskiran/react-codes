import React, {useState} from "react";


function HookCounterTwo(){

    const initialCount = 0;
    const [count, setCount] = useState(initialCount);

    function incrementByFive(){
        for(let i=0; i < 5; i++){
            setCount(prevCount => prevCount + 1);
           // console.log(prevCount);
        }
    }

    return(
        <>
            <div>
                Count: {count} &nbsp;
                <button onClick={() => setCount(count + 1)}>Increment</button>
                <button onClick={() => setCount(count - 1)}>Decrement</button>
                <button onClick={() => setCount(initialCount)}>Reset</button>
            </div>
            <div>
                <button onClick={incrementByFive}>Increment by 5</button>
            </div>
        </>
    );
}

export default HookCounterTwo;