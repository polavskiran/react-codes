import React from "react";
import './newStyles.css';

class DropDownTest extends React.Component{

    constructor(props){
        super(props);
        this.state = {names : [], text: ''};
        this.handleChange = this.handleChange.bind(this);
        this.addToList = this.addToList.bind(this);
    }

    addToList(e){
        e.preventDefault();

        if(this.state.text.length === 0){
            return;
        }

        const newItems = {
            text : this.state.text,
            id : Date.now()
        };

        this.setState( state => ({
            names : state.names.concat(newItems),
            text : ''
        }));
    }

    handleChange(e){
        this.setState(
                {text:e.target.value}
            );
    }

    render(){
        return(
            <div className='center'>
                <h1 className='primary'>Family Details</h1>
                <form onSubmit={this.addToList}>
                    <label className='font-m'>Family Names: </label>
                    <AddOptions names={this.state.names} />
                    <br />
                    <label>Enter Name to Add: </label>
                    <input value={this.state.text} onChange={this.handleChange}></input><br />
                    <button type="submit" className='button'>Add Name</button>
                </form>
            </div>
        );
    }
}

class AddOptions extends React.Component{
    render(){
        
        return(
            <select>
                {this.props.names.map(item =>(
                    <option key={item.id}>{item.text}</option>
                ))}
            </select>
        );
    }
}

export default DropDownTest;