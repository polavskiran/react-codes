import React from "react";
import { useState } from "react/cjs/react.development";

function SelectCourses() {

    //const [courses, setCourses] = useState([]);     // Create courses object

    const [items, setItems] = useState([]);     // Create items object

    function updateItems() {
        setItems([...items,{
            id: items.length,
            value: Math.floor(Math.random() * 10) + 1
        }])
    }

    const addItems = items.map(
        item => {
            return (
                <>                
                <li key={item.id}>
                    {item.value}
                    <input type="checkbox"></input>
                    </li>
                </>
            )
        }
    )

    return(
        <>
            <div className="divform">                
                <label> Set Items </label>
                <button onClick={updateItems}>Add Item</button>
                <ul>
                    {
                        addItems
                    }
                </ul>
            </div>
        </>
    );
}

export default SelectCourses;