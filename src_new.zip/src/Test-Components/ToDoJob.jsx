import React, {useState} from "react";

function ToDoJob(){

    const courses = [
        {
            course_name: "The Data Science Course 2021: Complete Data Science Bootcamp",
            instructor_name: "Gyanendra Singh Yadav"
        },
        {
            course_name: "Selenium WebDriver with Java -Basics to Advanced+Frameworks",
            instructor_name: "Gyanendra Singh Yadav"
        },
        {
            course_name: "NodeJS - The Complete Guide (MVC, REST APIs, GraphQL, Deno)",
            instructor_name: "Murali Venkatesan"
        },
        {
            course_name: "Advanced CSS and Sass: Flexbox, Grid, Animations and More!",
            instructor_name: "Murali Venkatesan"
        },
        {
            course_name: "Python for Data Science and Machine Learning Bootcamp",
            instructor_name: "Murali Venkatesan"
        },
        {
            course_name: "Test 123",
            instructor_name: "Test"
        },
        {
            course_name: "Python for Data Science and Machine Learning Bootcamp",
            instructor_name: "Murali Venkatesan"
        },
        {
            course_name: "Test 123",
            instructor_name: "Test"
        },
        {
            course_name: "Python for Data Science and Machine Learning Bootcamp",
            instructor_name: "Murali Venkatesan"
        }
    ];

    const [currentPage,setCurrentPage] = useState(1);

    const handleClick = (event) => {
        setCurrentPage(currentPage+1);
    }

    const todosPerPage = 4;
    const pageNumbers = [];
    for (let i=1; i <= Math.ceil(courses.length / todosPerPage); i++){
        pageNumbers.push(i);
    }

    const renderPageNumbers = pageNumbers.map(
        number => {
            return(
                <li key={number} onClick={handleClick}>
                    Page{number}
                </li>
            );
        }
    );

    return(
        <>
            <ul>
                {renderPageNumbers}
            </ul>
        </>
    );
}

export default ToDoJob;