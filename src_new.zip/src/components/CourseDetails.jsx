import React, {useState} from "react";
import {Button, ListGroup, Modal, ModalTitle} from "react-bootstrap";

function CourseDetails(props){

    console.log(props);

    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    function enrollSuccess(){
        return(
            document.getElementById('msg-enroll').innerText = "Course Enrolled Successfully",
            document.getElementById('msg-complete').innerText = ""
        );
    }

    function completeCourse(){
        return(
            document.getElementById('msg-complete').innerText = "Course Completed Successfully",
            document.getElementById('msg-enroll').innerText = ""
        );
    }

    return(
        <>
            <Modal show={props.open}>
                <Modal.Header>
                    <Modal.Title>Java Course</Modal.Title>
                </Modal.Header>
                <Modal.Body>Java is a high-level, class-based, object-oriented programming language
                    that is designed to have as few implementation dependencies as possible.

                    <ListGroup as="ul">
                        <ListGroup.Item as="li" active>
                            Cras justo odio
                        </ListGroup.Item>
                        <ListGroup.Item as="li">Dapibus ac facilisis in</ListGroup.Item>
                        <ListGroup.Item as="li" disabled>
                            Morbi leo risus
                        </ListGroup.Item>
                        <ListGroup.Item as="li">Porta ac consectetur ac</ListGroup.Item>
                    </ListGroup>

                </Modal.Body>
                <div id="msg-enroll"></div>
                <div id="msg-complete"></div>
                <Modal.Footer>
                    <Button variant="secondary" >
                        Close
                    </Button>
                    <Button variant="primary" onClick={enrollSuccess}>
                        Enroll
                    </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default CourseDetails;